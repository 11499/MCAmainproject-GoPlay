<?php
include('connection.php');
           $r_id=$_GET['tid'];
                $tn=$_POST['uid'];
                $query2="select * from tb_teams where user_id='$r_id'";
                $res2 = mysqli_query($conn, $query2);
                $rr = mysqli_fetch_array($res2);
                $lid=$rr["team_id"];           
$sql=mysqli_query($conn,"insert into tb_booking(trmn_id,team_id)values ('$tn','$lid')"); 
$result=mysqli_query($conn,$sql);
header('location:page1.php');

?>