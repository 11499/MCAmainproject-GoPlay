<?php
	include("connect.php");
?>
<html>
<head>
<title>Registration Form</title>
<link rel="stylesheet"  href="css/registercss.css">

  <script type="text/javaScript">
     function registration()
      {


          var pwd_expression = /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-])/;
          var letters = /^[A-Za-z]+$/;
          var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
          var regmob = /^[1-9]\d{9}$/;
          var regdate = /^\d{2}([./-])\d{2}\1\d{4}$/;
         
          if(document.getElementById("name").value ==='')
          {
            document.getElementById("demo").innerHTML = 'Please enter your name';
              return false;
          }
          else if(!letters.test(document.getElementById("name").value))
          {
            document.getElementById("demo").innerHTML = 'Name field required only alphabet characters';
              return false;
          }
         
          else if(document.getElementById("address").value=='')
          {
            document.getElementById("demo").innerHTML = 'Please enter your address';
              return false;

          }
          else if(!letters.test(document.getElementById("address").value))
          {
            document.getElementById("demo").innerHTML = 'address field required only alphabet characters';
              return false;

          }       
          else if(document.getElementById("email").value=='')
          {
            document.getElementById("demo").innerHTML = 'Please enter your user email id';
              return false;

          }
          else if (!filter.test(document.getElementById("email").value))
          {
            document.getElementById("demo").innerHTML = 'Invalid email';
              return false;

          }
          else if(document.getElementById("phone").value=='')
          {
             document.getElementById("demo").innerHTML = 'Please enter the user name.';
              return false;

          }
          
          else if (!regmob.test(document.getElementById("phone").value)) 
            {
                document.getElementById("demo").innerHTML = "Please Enter 10 Digit Mobile Number only";
                return false;
            }
           
          else if(document.getElementById("uname").value=='')
          {
            document.getElementById("demo").innerHTML = 'Please enter the username.';
              return false;

          }
          else if(!letters.test(document.getElementById("uname").value==''))
          {
            document.getElementById("demo").innerHTML = 'User name field required only alphabet characters';
              return false;

          }
          else if(document.getElementById("pass").value=='')
          {
            document.getElementById("demo").innerHTML = 'Please enter Password';
              return false;

          }
          else if(document.getElementById("cpass").value=='')
          {
            document.getElementById("demo").innerHTML = 'Enter Confirm Password';
              return false;

          }
          else if(!pwd_expression.test(document.getElementById("pass").value))
          {
            document.getElementById("demo").innerHTML = 'Upper case, Lower case, Special character and <br>Numeric letter are required in Password filed';
              return false;

          }
         
          else if(document.getElementById("pass").value.length < 6)
          {
            document.getElementById("demo").innerHTML = 'Password minimum length is 6';
              return false;

          }
          else if(document.getElementById("cpass").value.length > 12)
          {
            document.getElementById("demo").innerHTML = 'Password max length is 12';
              return false;

          }
          else if(document.getElementById("pass").value != document.getElementById("cpass").value)
          {
            document.getElementById("demo").innerHTML = 'Password not Matched';
              return false;

          }
          else
          {				                            
            document.getElementById("demo").innerHTML = 'Thank You for registering';
               return true;
          }
      }
    </script>
</head>
<body><center>
<div class="frm">
  <div class="header">
<h2>Register</h2>
</div>
<form action="reg.php" method="POST" name="frm"  onsubmit="return registration();" >
<div class="error"><p id="demo"></p></div>
<table border="0" align="center">
<tr>
<td><label> Name </label></td>
<td><input type="text" placeholder="Enter The First Name" name="name" id="name"></td>
</tr>

<td><label>Address </label></td>
<td><textarea rows="5"cols="20" placeholder="Enter your Address" id="address" name="address"></textarea></td>
</tr> 
<tr>
<td><label>Email </label></td>
<td><input type="text"placeholder="Enter The Email Id" id="email" name="email" required></td>
</tr>
<tr>
<td><label>Phone no  </label></td>
<td><input type="text"placeholder="Enter The Phone Number"id ="phone" name="phone"></td>
</tr>
<tr>
<td><label>User Name </label></td>
<td><input type="text"placeholder="Enter Your User Name" id="uname" name="uname"></td>
</tr>
<tr>
<td><label>Password </label></td>
<td><input  name="pass" type="password" id="pass" placeholder="Enter Your Password" /></td>
</tr>
<br>
<tr>
<td><label>Confirm Password</label></td>
<td><input  name="cpass" type="password" id="cpass" placeholder="Re-Enter Your Password" /></td>
</tr><br>
<tr>
  <td><input type ="hidden" name="usertype" value="user"></td>
    </tr>
</table>

<button type="submit" name="Click" >Register</button>
<div class="footer">
Already have Account?<a href="log1.php"> Login</a>
</div>
</div>
</form>
</body>
</html>
<?php
if(isset($_POST["Click"]))
{
$name=$_POST["name"];
$address=$_POST["address"];
$email=$_POST["email"];
$phone=$_POST["phone"];
$uname=$_POST["uname"];
$pass=$_POST["pass"];
$usertype=$_POST["usertype"];
$sql2="select * from log_tbl where uname='$uname' ";
$result=mysqli_query($con,$sql2);
$count=mysqli_num_rows($result);

if($count>0)
{
  
    ?>
    <script>
    alert("Sorry! Username Already in use");
    </script>
    <?php
  }
  else
  {

$sql="insert into reg_tbl(name,address,email,phone)values('$name','$address','$email','$phone')";
if(mysqli_query($con,$sql))
{
	$sql1="insert into log_tbl(uname,pass,usertype)values('$uname','$pass','$usertype')";
    ?>
    <script>
        alert("Registered Successfully");
    </script>
    <?php
if(mysqli_query($con,$sql1))
{ 
  if(headers_sent())
  {
  die('<script type="text/javascript">window.location.href="log1.php"</script>');
  }
  else{
  header("location:reg.php");
  die();
  }
   
}
}
else{
?>

<script>
alert("error");
</script>
<?php
}
}
}
mysqli_close($con);			
?>
