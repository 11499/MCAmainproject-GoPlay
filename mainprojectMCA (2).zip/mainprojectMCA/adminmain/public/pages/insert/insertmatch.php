<?php
include('../connection.php');
if(isset($_POST["Click"]))
{
            $un=$_POST['uname'];
            $tn=$_POST['tname'];
            $ttn=$_POST['ttname'];
$sql=mysqli_query($conn,"insert into tb_matchschedule(`match`, `team1`, `team2`)values ('$un','$tn','$ttn')"); 
//$sql=mysqli_query($con,"insert into add_category(type,description,theme)values ('$type','$description','$theme')");
$result=mysqli_query($conn,$sql);
//header('location:../manageschedule.php');
echo "<script>alert('Inserted Successfully');window.location.href='../manageschedule';</script>";

}
?>
