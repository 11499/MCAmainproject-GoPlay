<?php
include('../connection.php');
if(isset($_POST["Click"]))
{
            $tn=$_POST['name'];
            $np=$_POST['mobile'];
			$em=$_POST['email'];
            $pc=$_POST['place'];
			
$sql=mysqli_query($conn,"insert into tb_team(name,email,mobile,place)values ('$tn','$np','$em','$pc')"); 
//$sql=mysqli_query($con,"insert into add_category(type,description,theme)values ('$type','$description','$theme')");
$result=mysqli_query($conn,$sql);
header('location:../addnews.php');
}
?>