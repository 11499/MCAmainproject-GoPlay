<?php

    $servername="localhost";
    $username="root";
    $password="";
    $db="st_db";
    
    //create connection
    $conn=mysqli_connect($servername,$username,$password,$db);

    //check connection
    if(!$conn)
    {
        die("connection failed:".mysqli_connect_error());
    }
    
   // echo"connected successfully";
?>
  




























