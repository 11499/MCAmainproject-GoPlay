<?php 
session_start();

include('connection.php');
include('pdf_mc_table.php');
if(isset($_POST['genaratepdf']))
{
  $result = mysqli_query($conn,"SELECT tb_user.*,tb_teams.teamname,teamplayers.* FROM teamplayers JOIN tb_teams on teamplayers.team_id=tb_teams.team_id JOIN tb_user on teamplayers.user_id=tb_user.user_id") or die(mysqli_error($conn));
  $pdf = new PDF_MC_TABLE();
  $pdf->AddPage();

  $pdf->SetFont('Arial', 'B', 15);
  $pdf->Cell(176, 5, 'Player Details', 0, 0, 'C');
  $pdf->Ln();
  $pdf->Ln();
  $pdf->Ln();

  $pdf->SetFont('Arial','',10);
  
  $pdf->SetWidths(Array(11,30,30,30,30,30,30,30));

  $pdf->SetLineHeight(5);

  $pdf->SetFont('Arial','B',10);
  $pdf->Cell(11,5,"Sl No",1,0);
  $pdf->Cell(30,5," Name",1,0);
  $pdf->Cell(30,5,"mobile",1,0);
 
  $pdf->Cell(30,5,"place",1,0);
 
  $pdf->Ln();
  
  $pdf->SetFont('Arial','',10);	
  $i=1;
  foreach($result as $row) {
    $pdf->Row(Array(
        $i,
		$row['name'],
        $row['mobile'],
		$row['place'],
	
	));
	$i++;
  }
  $pdf->Output();
}
?>
