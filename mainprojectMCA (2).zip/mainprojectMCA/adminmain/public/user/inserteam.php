
<?php
session_start();
include 'connection.php';
if (isset($_SESSION['id'])) {
?>
<?php
include('connection.php');
if(isset($_POST["Click"]))
{            

    $ri= $_SESSION['id'];
    $r_id=$_GET['eid'];
            $tn=$_POST['name'];
            $np=$_POST['mobile'];
			$em=$_POST['email'];
            $pc=$_POST['pc'];
            $tm=$_POST['time'];
            $filepath1=pathinfo($_FILES['image']['name']) ;
            $extension1=$filepath1['extension'];
            $rd=  rand();
            $aname= $rd.'.'.$extension1;
            $pathinfo='../timage/'.$aname;
            move_uploaded_file($_FILES['image']['tmp_name'],$pathinfo);
			
$sql=mysqli_query($conn,"insert into tb_team(user_id,name,email,mobile,place,image,status)
values ('$ri','$tn','$em','$np','$pc','$aname','1')"); 
echo $sql;
$result=mysqli_query($conn,$sql);
header('location:addteam.php');
}
}
mysqli_close($conn);
?>