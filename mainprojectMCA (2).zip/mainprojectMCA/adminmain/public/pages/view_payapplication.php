<?php
session_start();
include 'connection.php';
if(isset($_SESSION['user_id']))
    $user_id=$_SESSION['user_id'];

$result=mysqli_query($conn,"SELECT  tb_bookingpay.*,tb_login.* from tb_bookingpay join tb_login on tb_bookingpay.log_id=tb_login.log_id ") or die(mysqli_error($conn));


include('pdf_mc_table.php');
$pdf = new PDF_MC_TABLE();
$pdf->AddPage();
$pdf->SetFont('Arial','B',15);	
$pdf->Cell(176, 5, 'Payment', 0, 0, 'C');
  $pdf->Ln();
  $pdf->Ln();
  $pdf->Ln();	
$row=mysqli_fetch_array($result);
$pdf->SetFont('Arial','',12);	
$pdf->Multicell(80,12,'Name : '. $row['username'],1);
$pdf->Multicell(80,12,'Amount : '. $row['tamount'],1);
$pdf->Multicell(80,12,'Payment status : '. $row['paystatus'],1);
$pdf->Multicell(80,12,'Date of payment : '. $row['date_added'],1);


$pdf->Output();
?>