<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<link rel="stylesheet" href="style.css" />





<div class="container">
    <h3 class="h3">Book  Tournament</h3>
    <div class="row">
        <div class="col-md-3 col-sm-6">
            <div class="product-grid4">
                <div class="product-image4">
                    <a href="#">
                        <img class="pic-1" src="images/cr2.jfif">
                        <img class="pic-2" src="images/cr2.jfif">
                    </a>
                    <ul class="social">
                        <li><a href="#" data-tip="Quick View"><i class="fa fa-eye"></i></a></li>
                        <li><a href="#" data-tip="Add to Wishlist"><i class="fa fa-shopping-bag"></i></a></li>
                        <li><a href="#" data-tip="Add to Cart"><i class="fa fa-shopping-cart"></i></a></li>
                    </ul>
                    <span class="product-new-label">New</span>
                    <span class="product-discount-label">soon</span>
                </div>
                <div class="product-content">
                    <h3 class="title"><a href="#">cricket tournament</a></h3>
                    <div class="price">
                        1000
                        <span>Registration fee</span>
                    </div>
                    <a class="add-to-cart" href="../payment/pay.php">Register Now</a>
                </div>
            </div>
        </div>
        <div class="col-md-3 col-sm-6">
            <div class="product-grid4">
                <div class="product-image4">
                    <a href="#">
                        <img class="pic-1" src="images/fb.jfif">
                        <img class="pic-2" src="images/fb.jfif">
                    </a>
                    <ul class="social">
                        <li><a href="#" data-tip="Quick View"><i class="fa fa-eye"></i></a></li>
                        <li><a href="#" data-tip="Add to Wishlist"><i class="fa fa-shopping-bag"></i></a></li>
                        <li><a href="#" data-tip="Add to Cart"><i class="fa fa-shopping-cart"></i></a></li>
                    </ul>
                    <span class="product-discount-label">SOON</span>
                </div>
                <div class="product-content">
                    <h3 class="title"><a href="#">football Tournament</a></h3>
                    <div class="price">
                            5000
                        <span>Registration fee</span>
                    </div>
                    <a class="add-to-cart" href="../payment/pay.php">Register now</a>
                </div>
            </div>
        </div>
        <div class="col-md-3 col-sm-6">
            <div class="product-grid4">
                <div class="product-image4">
                    <a href="#">
                        <img class="pic-1" src="images/kab.jfif">
                        <img class="pic-2" src="images/kab.jfif">
                    </a>
                    <ul class="social">
                        <li><a href="#" data-tip="Quick View"><i class="fa fa-eye"></i></a></li>
                        <li><a href="#" data-tip="Add to Wishlist"><i class="fa fa-shopping-bag"></i></a></li>
                        <li><a href="#" data-tip="Add to Cart"><i class="fa fa-shopping-cart"></i></a></li>
                    </ul>
                    <span class="product-new-label">New</span>
                    <span class="product-discount-label">soon</span>
                </div>
                <div class="product-content">
                    <h3 class="title"><a href="#">Kabadi tournament</a></h3>
                    <div class="price">
                        1000
                        <span>Registration fee</span>
                    </div>
                    <a class="add-to-cart" href="../payment/pay.php">Registration now</a>
                </div>
            </div>
        </div>
        <div class="col-md-3 col-sm-6">
            <div class="product-grid4">
                <div class="product-image4">
                    <a href="#">
                        <img class="pic-1" src="images/ho2.jfif">
                        <img class="pic-2" src="images/ho2.jfif">
                    </a>
                    <ul class="social">
                        <li><a href="#" data-tip="Quick View"><i class="fa fa-eye"></i></a></li>
                        <li><a href="#" data-tip="Add to Wishlist"><i class="fa fa-shopping-bag"></i></a></li>
                        <li><a href="#" data-tip="Add to Cart"><i class="fa fa-shopping-cart"></i></a></li>
                    </ul>
                    <span class="product-new-label">New</span>
                    <span class="product-discount-label">soon</span>
                </div>
                <div class="product-content">
                    <h3 class="title"><a href="#">Hockey Tournament</a></h3>
                    <div class="price">
                        2500
                        <span>Registration fee</span>
                    </div>
                    <a class="add-to-cart" href="../payment/pay.php">Register now</a>
                </div>
            </div>
        </div>
    </div>
</div>
<hr>

