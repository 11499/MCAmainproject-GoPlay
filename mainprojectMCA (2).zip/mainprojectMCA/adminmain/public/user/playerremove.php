<?php

	
	include('connection.php');
    
    $r_id=$_GET['uid'];
    $query = "select * from tb_user where user_id='$r_id'";
    $res = mysqli_query($conn, $query);
    $r = mysqli_fetch_array($res);
    $lid=$r["user_id"]; 
    #echo $pid;
	mysqli_query($conn,"update `teamplayers` set status=1 where user_id='$lid'");
    // mysqli_query($conn,"");
    header('location:manageteam.php');
?>