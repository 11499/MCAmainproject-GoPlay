<?php
	$r_id=$_GET['uid'];
	include('connection.php');

    $query = "select * from tb_result where result_id='$r_id'";
    $res = mysqli_query($conn, $query);
    $r = mysqli_fetch_array($res);
    $lid=$r["result_id"]; 
    #echo $pid;

	
	mysqli_query($conn,"update `tb_result` set status=1 where result_id='$lid'");
	header('location:../result.php');
?>