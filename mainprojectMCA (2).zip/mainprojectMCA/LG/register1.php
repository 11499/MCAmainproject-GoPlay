<?php
	include("connection.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Register</title>

    <!-- Font Icon -->
    <link rel="stylesheet" href="fonts/material-icon/css/material-design-iconic-font.min.css">

    <!-- Main css -->
    <link rel="stylesheet" href="css/style.css">
    

</head>

<body>

    <div class="main">

        <!-- Sign up form -->
        <section class="signup">
            <div class="container">
                <div class="signup-content">
                    <div class="signup-form">
                        <h2 class="form-title">Registration</h2>
                        
                        <form action="register1.php" method="POST" id="form2" name="form2" autocomplete="off"  " >
                        <div class="error"><p id="demo"></p></div>
                            <div class="form-group">
                              
                                <label for="name"><i class="zmdi zmdi-account material-icons-name"></i></label>
                                <input type="text" name="name" id="name" placeholder="Name"  required onchange="Validate();"/>
                                <span id="msg1" style="color:red;"></span>
                              <script>
                             
                    function Validate() 
                    {
                        var val = document.getElementById('name').value;
                    
                        if (!val.match(/^[A-Z][A-Za-z\ ]{2,}$/)) 
                        {
                            document.getElementById('msg1').innerHTML="Start with a Capital letter & Only alphabets  are allowed!!";
                                        document.getElementById('name').value = "";
                            return false;
                        }
                    document.getElementById('msg1').innerHTML=" ";
                        return true;
                    }
                    </script>
            
                            </div>
                               <div class="form-group">
                              
                                <label for="name"><i class="zmdi zmdi-account material-icons-name"></i></label>
                                <input type="text" name="username" id="username" placeholder=" User Name"  required onchange="Validate();"/>
                                <span id="msg2" style="color:red;"></span>
                              <script>
                             
                    function Validate1() 
                    {
                        var val = document.getElementById('username').value;
                    
                        if (!val.match(/^[A-Z][A-Za-z0-9]{5,}/)) 
                        {
                            document.getElementById('msg2').innerHTML="Start with a Capital letter & Only alphabets and Numbers  are allowed...Minimum 6 characters required!!";
                                        document.getElementById('username').value = "";
                            return false;
                        }
                    document.getElementById('msg2').innerHTML=" ";
                        return true;
                    }
                    </script>
                            </div>
                          
                            <div class="form-group">
                                <label for="pass"><i class="zmdi zmdi-lock"></i></label>
                                <input type="password" name="passwd" id="passwd" placeholder="Password"  required onchange="Validp();"/>
                                <span id="msg6" style="color:red;"></span>
<script>		
function Validp() 
{
    var val = document.getElementById('passwd').value;

    if (!val.match(/^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-])/)) 
    {
        document.getElementById('msg6').innerHTML="Upper case, Lower case, Special character and Numeric number are required in Password filed";
		
		     document.getElementById('passwd').value = "";
        return false;
    }
document.getElementById('msg6').innerHTML=" ";
    return true;
}
		</script>
                            </div>
                            <div class="form-group">
                                <label for="re-pass"><i class="zmdi zmdi-lock-outline"></i></label>
                                <input type="password" name="conpassword" id="conpassword"  placeholder="Repeat your password"  required onchange="check();"/>
                                <span id="msg7" style="color:red;"></span>
<script>
function check()
{
                            var pas1=document.getElementById("passwd");
							  var pas2=document.getElementById("conpassword");
							
							  if(pas1.value=="")
	{
		document.getElementById('msg7').innerHTML="Password can't be null!!";
		pas1.focus();
		return false;
	}
	if(pas2.value=="")
	{
		document.getElementById('msg7').innerHTML="Please confirm password!!";
		pass2.focus();
		return false;
	}
	if(pas1.value!=pas2.value)
	{
		document.getElementById('msg7').innerHTML="Passwords does not match!!";
		pas1.focus();
		return false;
	}
     document.getElementById('msg7').innerHTML=" "; 
	return true;
	
}
	</script>
					
                            </div>
                            <div class="form-group">
                                <label for="email"><i class="zmdi zmdi-email"></i></label>
                                <input type="email" name="email" id="email" placeholder="Your Email"    required onchange="Validata();"/>
                                <span id="msg5" style="color:red;"></span>
<script>		
function Validata() 
{
    var val = document.getElementById('email').value;

    if (!val.match(/^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/)) 
    {
        document.getElementById('msg5').innerHTML="Enter a Valid Email";
		
		     document.getElementById('email').value = "";
        return false;
    }
document.getElementById('msg5').innerHTML=" ";
    return true;
}

		</script>

                            </div>
                            <div class="form-group">
                                <label for="name"><i class="zmdi zmdi-account material-icons-name"></i></label>
                                <input type="text" name="mobile" id="mobile"  placeholder="Your Mobile Number" required onchange="Validat();"/>
                                <span id="msg4" style="color:red;"></span>
			
      <script>
function Validat() 
{
var val = document.getElementById('mobile').value;

if (!val.match(/^[789][1-9]{9}$/))
{
document.getElementById('msg4').innerHTML="Only Numbers are allowed and must contain 10 number";


document.getElementById('mobile').value = "";
return false;
}
document.getElementById('msg4').innerHTML=" ";
return true;
}
</script>
      

                            </div>
                            <div class="form-group">
                                <label for="name"><i class="zmdi zmdi-account material-icons-name"></i></label>
                                <input type="text" name="place" id="place" placeholder="Place" required onchange="Validate();"/>
                                <span id="msg8" style="color:red;"></span>
                               <script>
                             
                             function Validate() 
                             {
                                 var val = document.getElementById('place').value;
                             
                                 if (!val.match(/^[A-Z][A-Za-z\ ]{2,}$/)) 
                                 {
                                     document.getElementById('msg8').innerHTML="Start with a Capital letter & Only alphabets  are allowed!!";
                                                 document.getElementById('place').value = "";
                                     return false;
                                 }
                             document.getElementById('msg8').innerHTML=" ";
                                 return true;
                             }
                             </script>
                            </div>
                            
                            <div class="form-group">
                                <label for="name"><i class="zmdi zmdi-account material-icons-name"></i></label>
                                
                                <input type="text" name="sn" id="sn" placeholder="Spotrs Name" required onchange="Validate();" />
                                <span id="msg9" style="color:red;"></span>
                               <script>
                             
                             function Validate() 
                             {
                                 var val = document.getElementById('sn').value;
                             
                                 if (!val.match(/^[A-Z][A-Za-z\ ]{2,}$/)) 
                                 {
                                     document.getElementById('msg9').innerHTML="Start with a Capital letter & Only alphabets  are allowed!!";
                                                 document.getElementById('sn').value = "";
                                     return false;
                                 }
                             document.getElementById('msg9').innerHTML=" ";
                                 return true;
                             }
                             </script>
                            </div>
                            <div class="form-group">
                                <label for="name"><i class="zmdi zmdi-account material-icons-name"></i></label>
                                <input type="text" name="tn" id="tn" placeholder="Previous team name" required onchange="Validate();"/>
                                <span id="msg10" style="color:red;"></span>
                               <script>
                             
                             function Validate() 
                             {
                                 var val = document.getElementById('tn').value;
                             
                                 if (!val.match(/^[A-Z][A-Za-z\ ]{2,}$/)) 
                                 {
                                     document.getElementById('msg10').innerHTML="Start with a Capital letter & Only alphabets  are allowed!!";
                                                 document.getElementById('tn').value = "";
                                     return false;
                                 }
                             document.getElementById('msg10').innerHTML=" ";
                                 return true;
                             }
                             </script>
                            </div>
                            <div class="form-group">
                                <label for="name"><i class="zmdi zmdi-account material-icons-name"></i></label>
                                <input type="text" name="pos" id="pos" placeholder="Position"required onchange="Validate();"/>
                                <span id="msg11" style="color:red;"></span>
                               <script>
                             
                             function Validate() 
                             {
                                 var val = document.getElementById('pos').value;
                             
                                 if (!val.match(/^[A-Z][A-Za-z\ ]{2,}$/)) 
                                 {
                                     document.getElementById('msg11').innerHTML="Start with a Capital letter & Only alphabets  are allowed!!";
                                                 document.getElementById('pos').value = "";
                                     return false;
                                 }
                             document.getElementById('msg11').innerHTML=" ";
                                 return true;
                             }
                             </script>
                            </div>
                            <div class="form-group">
                                <label for="name"><i class="zmdi zmdi-account material-icons-name"></i></label>
                                <input type="text" name="exp" id="exp" placeholder="Year of Experience" required onchange="Validate();"/>
                                <span id="msg12" style="color:red;"></span>
                               <script>
                             
                             function Validate() 
                             {
                                 var val = document.getElementById('exp').value;
                             
                                 if (!val.match(/^[A-Z][A-Za-z\ ]{2,}$/)) 
                                 {
                                     document.getElementById('msg12').innerHTML="Start with a Capital letter & Only alphabets  are allowed!!";
                                                 document.getElementById('exp').value = "";
                                     return false;
                                 }
                             document.getElementById('msg12').innerHTML=" ";
                                 return true;
                             }
                             </script>
                            </div>
                            <div class="form-group">
                                <label for="name"><i class="zmdi zmdi-account material-icons-name"></i></label>
                                <input type="text" name="eligibility" id="eligibility" placeholder="Eligibility" required onchange="Validate();"/>
                                <span id="msg13" style="color:red;"></span>
                               <script>
                             
                             function Validate() 
                             {
                                 var val = document.getElementById('eligibility').value;
                             
                                 if (!val.match(/^[A-Z][A-Za-z\ ]{2,}$/)) 
                                 {
                                     document.getElementById('msg13').innerHTML="Start with a Capital letter & Only alphabets  are allowed!!";
                                                 document.getElementById('eligibility').value = "";
                                     return false;
                                 }
                             document.getElementById('msg13').innerHTML=" ";
                                 return true;
                             }
                             </script>
                            </div>
                            
                            <div class="form-group form-button">
                            <button type="submit" class="form-submit" name="Click" >Register</button>   </div>
                        </form>
                    </div>
                    <div class="signup-image">
                        <img src="images/spot.jpg" alt="sing up image">
                        <a href="login.php" class="signup-image-link">I am already member</a>
                    </div>
                </div>
            </div>
        </section>

        <!-- Sing in  Form -->
       

    </div>
   
    <!-- JS 
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="js/main.js"></script>-->
</body><!-- This templates was made by Colorlib (https://colorlib.com) -->
</html>
<?php
include("connection.php");
if(isset($_POST["Click"]))
{
  $name=$_POST['name'];
  $uname=$_POST['username'];
  $pwd=$_POST['passwd'];
  $email=$_POST['email'];
  $mob=$_POST['mobile'];
  $plc=$_POST['place'];
  $sn=$_POST['sn'];
  $tn=$_POST['tn'];
  $pos=$_POST['pos'];
  $exp=$_POST['exp'];
  $elg=$_POST['eligibility'];

$sql2="select * from tb_login where username='$uname' ";
$result=mysqli_query($conn,$sql2);
$count=mysqli_num_rows($result);
if($count>0)
{
  
    ?>
    <script>
    alert("Sorry! Username Already in use");
    </script>
    <?php
  }
  else
  {
    $sql1="insert into tb_login(username,passwd,usertype,status)values('$uname','$pwd','user',0)";

if(mysqli_query($conn,$sql1))
{
  $last_id = mysqli_insert_id($conn);
  $result1=mysqli_query($conn,"select * from tb_login where username='$uname'");
  $row=mysqli_fetch_assoc($result1);
  $sql="insert into tb_user(log_id,name,email,mobile,place,sp_type,pt_name,position,exp,eligibility) values ('$row[log_id]','$name','$email','$mob','$plc','$sn','$tn','$pos','$exp','$elg')";

  //$sql="insert into reg_tbl(name,lname,log_id,address,email,mphone)values('$name','$lname','$last_id','$address','$email','$mphone')";  
if(mysqli_query($conn,$sql))
{ 
  if(headers_sent())
  {
  die('<script type="text/javascript">window.location.href="login.php"</script>');
  }
  else{
  header("location:login.php");
  die();
  }
   
}
}
else{
?>

<script>
alert("error");
</script>
<?php
}
}
}
mysqli_close($conn);			
?>