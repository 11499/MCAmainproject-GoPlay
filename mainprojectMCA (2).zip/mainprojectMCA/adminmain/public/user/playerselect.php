<?php

	$r_id=$_GET['uid'];
    $rr=$_GET['tid'];
	include('connection.php');
    $tid = $_GET['tid'];
    $query = "select * from tb_user where user_id='$r_id'";
    //$query2="select team_id from tb_teams where user_id=$r_id";
    $res = mysqli_query($conn, $query);
    $r = mysqli_fetch_array($res);
    $lid=$r["log_id"]; 
    #echo $pid;
	mysqli_query($conn,"update `tb_login` set usertype='player',approve=1 where log_id='$lid'");
    // mysqli_query($conn,"");
    
    mysqli_query($conn,"INSERT INTO `teamplayers`(`team_id`,`user_id`) VALUES ('$rr','$r_id')");
	header('location:addteam.php');
?>