<html>
<head>

<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<link rel="stylesheet" href="style.css" />

<link href="css/main.css" rel="stylesheet">
</head>
<body>

<div class="container">
    <h3 class="h3">Book Tournament</h3>
    <div class="row">
  
        <div class="col-md-3 col-sm-6">
        <?php
include('connection.php');
$sel_query="SELECT * FROM tb_tournament"; 
$result = mysqli_query($conn,$sel_query);
while($row = mysqli_fetch_assoc($result)) { ?>

            <div class="product-grid4">
                <div class="product-image4">
                    <a href="#">
                        <img class="pic-1" src="images/tr2.jfif">
                        <img class="pic-2" src="images/tr2.jfif">
                    </a>
                    <ul class="social">
                   <!-- <li><a href="#" data-tip="Quick View"><i class="fa fa-eye"></i></a></li>-->
                        <li><a href="#" data-tip="Add to Wishlist"><i class="fa fa-shopping-bag"></i></a></li>
                       </ul>
                    <span class="product-new-label">New</span>
                    <button type="button" class="btn mr-2 mb-2 btn-primary" data-toggle="modal" data-target="#exampleModal">
                                           View Details
                                        </button> </div>
                <div class="product-content">
                    <h3 class="title"><a href="#"><?php echo $row["t_name"]; ?></a></h3>
                    <div class="price"><b>Reg fee :<b>
                    <?php echo $row["price"]; ?>
                        
                    </div>
                    <a class="add-to-cart" href="../payment/pay.php">Register Now</a>
                </div>
            </div>
            <?php  } ?>
        </div>
        
    </div>
</div>

<script type="text/javascript" src="../assets/scripts/main.js"></script>
<html>
<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Tournament Details</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <?php
include('connection.php');
$sel_query="SELECT * FROM tb_tournament"; 
$result = mysqli_query($conn,$sel_query);
$row = mysqli_fetch_assoc($result) ?>
            <div class="modal-body">
                <p class="mb-0">place :<?php echo $row["place"]; ?></p>
                <p class="mb-0">stadium:<?php echo $row["stadium"]; ?></p>
                <p class="mb-0">Time :<?php echo $row["time"]; ?></p>
                <p class="mb-0">start date :<?php echo $row["start_date"]; ?></p>
                <p class="mb-0">end_date<?php echo $row["end_date"]; ?></p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
              
            </div>
        </div>
    </div>
</div>


