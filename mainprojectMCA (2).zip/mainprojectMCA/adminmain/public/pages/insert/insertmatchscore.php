<?php
include('../connection.php');
if(isset($_POST["Click"]))
{
            $un=$_POST['tname'];
            $tn=$_POST['ttname'];
            $t=$_POST['t'];
$sql=mysqli_query($conn,"insert into tb_matchscore(`ms_id`, `team1score`, `team2score`)values ('$t','$un','$tn')"); 
//$sql=mysqli_query($con,"insert into add_category(type,description,theme)values ('$type','$description','$theme')");
$result=mysqli_query($conn,$sql);
//header('location:../manageschedule.php');
echo "<script>alert('Inserted Successfully');window.location.href='../manageschedule';</script>";

}
?>