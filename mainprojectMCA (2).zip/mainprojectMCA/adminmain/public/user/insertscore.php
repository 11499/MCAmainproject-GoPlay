<?php
include('connection.php');
if(isset($_POST["Click"]))
{
            $tn=$_POST['p_name'];
            $np=$_POST['t_name'];
			$em=$_POST['score'];
         
			
//$sql=mysqli_query($conn,"insert into tb_playeresult(name,tournamentname,score,status)values ('$tn','$np','$em','1')"); 
			
$sql=mysqli_query($conn,"insert into tb_playeresult(score,status)values ('$em','1')"); 

echo $sql;
$result=mysqli_query($conn,$sql);
header('location:addscore.php');
}
?>