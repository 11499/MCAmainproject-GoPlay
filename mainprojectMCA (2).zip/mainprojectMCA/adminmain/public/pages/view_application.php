<?php
session_start();
include 'connection.php';
if(isset($_SESSION['user_id']))
    $user_id=$_SESSION['user_id'];

$result=mysqli_query($conn,"SELECT * FROM `tb_user` where user_id=$user_id") or die(mysqli_error($conn));


include('pdf_mc_table.php');
$pdf = new PDF_MC_TABLE();
$pdf->AddPage();
$pdf->SetFont('Arial','B',15);	
$pdf->Cell(176, 5, 'View Details', 0, 0, 'C');
  $pdf->Ln();
  $pdf->Ln();
  $pdf->Ln();	
$row=mysqli_fetch_array($result);
$pdf->SetFont('Arial','',12);	
$pdf->Multicell(80,12,'name : '. $row['name'],1);
$pdf->Multicell(80,12,'email : '. $row['email'],1);
$pdf->Multicell(80,12,'moblie : '. $row['mobile'],1);
$pdf->Multicell(80,12,'place : '. $row['place'],1);
$pdf->Multicell(80,12,'sports: '. $row['sp_type'],1);

$pdf->Output();
?>