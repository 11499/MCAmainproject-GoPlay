<?php
	$r_id=$_GET['uid'];
	include('connection.php');

    $query = "select * from tb_news where n_id='$r_id'";
    $res = mysqli_query($conn, $query);
    $r = mysqli_fetch_array($res);
    $lid=$r["n_id"]; 
    #echo $pid;

	
	mysqli_query($conn,"delete from tb_news where n_id=$lid");
	header('location:managenews.php');
?>