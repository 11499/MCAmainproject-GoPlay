<?php
	$r_id=$_GET['uid'];
	include('connection.php');

    $query = "select * from tb_tournament where trmn_id='$r_id'";
    $res = mysqli_query($conn, $query);
    $r = mysqli_fetch_array($res);
    $lid=$r["trmn_id"]; 
    #echo $pid;

	
	mysqli_query($conn,"delete from tb_tournament where trmn_id=$lid");
	header('location:managetournament.php');
?>