<?php
include('../connection.php');
if(isset($_POST["Click"]))
{
            $tn=$_POST['tourname'];
            $np=$_POST['tmname'];
            $up=$_POST['uname'];
			$sp=$_POST['score'];
$sql=mysqli_query($conn,"INSERT INTO `tb_score`( `trmn_id`, `team_id`, `user_id`, `score`) VALUES ('$tn','$np','$up','$sp')"); 

$result=mysqli_query($conn,$sql);
//header('location:../managescore.php');
echo "<script>alert('Inserted Successfully');window.location.href='../managescore';</script>";

}
?>