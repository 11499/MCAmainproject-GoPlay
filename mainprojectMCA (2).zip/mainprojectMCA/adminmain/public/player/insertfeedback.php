<?php
include('connection.php');

if(isset($_POST["Click"]))
{           $r_id=$_GET['eid'];
             
            $tn=$_POST['name'];
           
$sql=mysqli_query($conn,"insert into tb_feedback(user_id,feedback)values ('$r_id','$tn')"); 
$result=mysqli_query($conn,$sql);
header('location:feedback.php');
}
?>