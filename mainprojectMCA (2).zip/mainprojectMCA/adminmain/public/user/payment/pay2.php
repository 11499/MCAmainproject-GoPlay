<?php
include('connection.php');
                $r_id=$_GET['tid'];
                $tn=$_GET['uid'];
                $query2="select * from tb_teams where user_id='$r_id'";
                $res2 = mysqli_query($conn, $query2);
                $rr = mysqli_fetch_array($res2);
                $lid=$rr["team_id"];           
$sql=mysqli_query($conn,"insert into tb_booking(trmn_id,team_id,status)values ('$tn','$lid','Requested')"); 
$result=mysqli_query($conn,$sql);
header('location:paymentgateway.php');
?>