<?php
	$r_id=$_GET['uid'];
	include('connection.php');

    $query = "select * from tb_teamjoin where tj_id='$r_id'";
    $res = mysqli_query($conn, $query);
    $r = mysqli_fetch_array($res);
    $lid=$r["tj_id"]; 
    #echo $pid;

	mysqli_query($conn,"update `tb_teamjoin` set approve=0 where tj_id='$lid'");
	header('location:request.php');
?>