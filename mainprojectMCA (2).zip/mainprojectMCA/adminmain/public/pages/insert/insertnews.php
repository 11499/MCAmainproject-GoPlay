<?php
include('../connection.php');
if(isset($_POST["Click"]))
{
            $tn=$_POST['name'];
            $np=$_POST['des'];
			
$sql=mysqli_query($conn,"insert into tb_news(titile,description)values ('$tn','$np')"); 
$result=mysqli_query($conn,$sql);
//header('location:../managenews.php');
echo "<script>alert('Inserted Successfully');window.location.href='../managenews';</script>";

}
?>
