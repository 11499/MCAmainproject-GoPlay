<?php
session_start();
include 'connection.php';
if (isset($_SESSION['id'])) {
?>
<?php
	include 'connection.php';
  
    $sql="select *from `tb_user` ";
   
    $result=mysqli_query($conn,$sql);
    
    $row=mysqli_fetch_assoc($result);

       
    

   if(isset($_POST['submit']))
   {
    $r_id=$_SESSION['id'];
    $name=$_POST['name'];
    $cat=$_POST['email'];
    $mob=$_POST['mobile'];
    $place=$_POST['place'];
    $st=$_POST['st'];
  
     
     
     
     mysqli_query($conn,"UPDATE `tb_user` SET `name`='$name',`email`='$cat',
     `mobile`='$mob',`place`='$place' where user_id='$r_id'");
       
    
          echo "<script>alert('Updated');</script>";
            header("location: page1.php");
     
   }
    

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <!--  This file has been downloaded from bootdey.com @bootdey on twitter -->
    <!--  All snippets are MIT license http://bootdey.com/license -->
    <title>Go-Play</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<script src="https://code.jquery.com/jquery-1.10.2.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
<?php
	$r_id=$_SESSION['id'];
	include('connection.php');
    $query = "select * from tb_user where user_id='$r_id'";
  
$result = mysqli_query($conn,$query);
$row = mysqli_fetch_assoc($result)
    
?>
<section class="bg-light">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 mb-4 mb-sm-5">
                <div class="card card-style1 border-0">
                    <div class="card-body p-1-9 p-sm-2-3 p-md-6 p-lg-7">
                        <div class="row align-items-center">
                            
                            <div class="col-lg-6 px-xl-10">
                                <div class="bg-secondary d-lg-inline-block py-1-9 px-1-9 px-sm-6 mb-1-9 rounded">
                                    <h3 class="h2 text-white mb-0"><?php echo $row["name"]; ?></h3>
                                    <span class="text-primary">player</span>
                                </div>
                                <ul class="list-unstyled mb-1-9">
                                <?php
include('connection.php');
$new=$_SESSION['id'];
$sel_query="SELECT * FROM tb_user where user_id='$new'"; 
$result = mysqli_query($conn,$sel_query);
$row=mysqli_fetch_assoc($result);
 ?>
              <h1 class="text-3xl font-semibold"></h1>
              <form  name="form" id="form" method="POST" action=''><p id="demo"></p>
                                            <div class="position-relative row form-group"><label  class="col-sm-2 col-form-label">Name</label>
                                                <div class="col-sm-10"><input name="name" id="name" placeholder="<?php echo $row["name"]; ?>" type="text" class="form-control"></div>
                                            </div>
                                            <div class="position-relative row form-group"><label  class="col-sm-2 col-form-label">Email</label>
                                                <div class="col-sm-10"><input name="email" id="email" placeholder="<?php echo $row["email"]; ?>" type="text" class="form-control"></div>
                                            </div>
                                            <div class="position-relative row form-group"><label  class="col-sm-2 col-form-label">Mobile</label>
                                                <div class="col-sm-10"><input name="mobile" id="mobile" placeholder="<?php echo $row["mobile"]; ?>" type="text" class="form-control"></div>
                                            </div>
                                            <div class="position-relative row form-group"><label  class="col-sm-2 col-form-label">Place</label>
                                                <div class="col-sm-10"><input name="place" id="place" placeholder="<?php echo $row["place"]; ?>" type="text" class="form-control"></div>
                                            </div>
                                                                                       
                                            <div class="position-relative row form-check">
                                                <div class="col-sm-10 offset-sm-2">
                                                <button type="submit" name="submit" id="submit"  value='Submit' class="btn-open-options btn btn-warning" >Update</button>   </div>
                         <!--  <button class="btn btn-secondary">Submit</button>-->
                                                </div>
                                            </div>
                                           
                                        </form>

                                </ul>
                                <ul class="social-icon-style1 list-unstyled mb-0 ps-0">
                                    <li><a href="#!"><i class="ti-twitter-alt"></i></a></li>
                                    <li><a href="#!"><i class="ti-facebook"></i></a></li>
                                    <li><a href="#!"><i class="ti-pinterest"></i></a></li>
                                    <li><a href="#!"><i class="ti-instagram"></i></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
</section>

<style type="text/css">
body{margin-top:20px;}
.card-style1 {
    box-shadow: 0px 0px 10px 0px rgb(89 75 128 / 9%);
}
.border-0 {
    border: 0!important;
}
.card {
    position: relative;
    display: flex;
    flex-direction: column;
    min-width: 0;
    word-wrap: break-word;
    background-color: #fff;
    background-clip: border-box;
    border: 1px solid rgba(0,0,0,.125);
    border-radius: 0.25rem;
}

section {
    padding: 120px 0;
    overflow: hidden;
    background: #fff;
}
.mb-2-3, .my-2-3 {
    margin-bottom: 2.3rem;
}

.section-title {
    font-weight: 600;
    letter-spacing: 2px;
    text-transform: uppercase;
    margin-bottom: 10px;
    position: relative;
    display: inline-block;
}
.text-primary {
    color: #ceaa4d !important;
}
.text-secondary {
    color: #15395A !important;
}
.font-weight-600 {
    font-weight: 600;
}
.display-26 {
    font-size: 1.3rem;
}

@media screen and (min-width: 992px){
    .p-lg-7 {
        padding: 4rem;
    }
}
@media screen and (min-width: 768px){
    .p-md-6 {
        padding: 3.5rem;
    }
}
@media screen and (min-width: 576px){
    .p-sm-2-3 {
        padding: 2.3rem;
    }
}
.p-1-9 {
    padding: 1.9rem;
}

.bg-secondary {
    background: #15395A !important;
}
@media screen and (min-width: 576px){
    .pe-sm-6, .px-sm-6 {
        padding-right: 3.5rem;
    }
}
@media screen and (min-width: 576px){
    .ps-sm-6, .px-sm-6 {
        padding-left: 3.5rem;
    }
}
.pe-1-9, .px-1-9 {
    padding-right: 1.9rem;
}
.ps-1-9, .px-1-9 {
    padding-left: 1.9rem;
}
.pb-1-9, .py-1-9 {
    padding-bottom: 1.9rem;
}
.pt-1-9, .py-1-9 {
    padding-top: 1.9rem;
}
.mb-1-9, .my-1-9 {
    margin-bottom: 1.9rem;
}
@media (min-width: 992px){
    .d-lg-inline-block {
        display: inline-block!important;
    }
}
.rounded {
    border-radius: 0.25rem!important;
}
</style>

<script type="text/javascript">

</script>
</body>
</html><?php
} else {
  if (headers_sent()) {
    die('<script type="text/javascript">window.location.href="login.php?e=1"</script>');
  } else {
    header("location:login.php?e=1");
    die();
  }
}
?>