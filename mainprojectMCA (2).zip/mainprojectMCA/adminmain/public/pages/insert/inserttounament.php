<?php
include('../connection.php');
if(isset($_POST["Click"]))
{
   

            $tname=$_POST['name'];
            $sn=$_POST['sn'];
			$place=$_POST['place'];
            $st=$_POST['st'];
            $tm=$_POST['time'];
            $sd=$_POST['sdate'];
                        $prc=$_POST['pc'];
            $filepath1=pathinfo($_FILES['image']['name']) ;
            $extension1=$filepath1['extension'];
            $rd=  rand();
            $aname= $rd.'.'.$extension1;
            $pathinfo='../timage/'.$aname;
            move_uploaded_file($_FILES['image']['tmp_name'],$pathinfo);
$sql=mysqli_query($conn,"insert into tb_tournament(t_name,cat,place,stadium,time,start_date,price,image)values ('$tname','$sn','$place','$st','$tm','$sd','$prc','$aname')"); 
//$sql=mysqli_query($con,"insert into add_category(type,description,theme)values ('$type','$description','$theme')");
$result=mysqli_query($conn,$sql);
//header('location:../managetournament.php');
echo "<script>alert('Inserted Successfully');window.location.href='../managetournament';</script>";


}
?>