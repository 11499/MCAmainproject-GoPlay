<?php
	$r_id=$_GET['uid'];
	include('connection.php');

    $query = "select * from tb_user where user_id='$r_id'";
    $res = mysqli_query($conn, $query);
    $r = mysqli_fetch_array($res);
    $lid=$r["log_id"]; 
    #echo $pid;

	
	mysqli_query($conn,"update `tb_login` set status=0 where log_id='$lid'");
	//header('location:manageuser.php');
    echo "<script>alert('Blocked Successfully');window.location.href='../managesuser';</script>";

?>