<?php
include('../connection.php');
if(isset($_POST["Click"]))
{
            $tn=$_POST['tname'];
            $np=$_POST['place'];
			$mobile=$_POST['mobile'];
            $email=$_POST['email'];
			
$sql=mysqli_query($conn,"insert into tb_teams(teamname,mobile,email,place,status)values ('$tn','$mobile','$email','$np','1')"); 
$result=mysqli_query($conn,$sql);
//header('location:../manageteams.php');
echo "<script>alert('Inserted Successfully');window.location.href='../manageteams';</script>";

}
?>