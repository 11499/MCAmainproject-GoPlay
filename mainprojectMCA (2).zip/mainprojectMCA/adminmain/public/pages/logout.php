<?php
session_start();
include "connection.php";

if ($_SESSION['id']) {
    session_destroy();
    header("location:../../../LG/login.php");
}