<?php

	
	include('connection.php');
    
    $r_id=$_GET['uid'];
  
    #echo $pid;
	mysqli_query($conn,"update `tb_booking` set canselreq='requested' where book_id='$r_id'");
    // mysqli_query($conn,"");
    
    header('location:bstatus.php');
?>