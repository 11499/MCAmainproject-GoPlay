<?php
include('connection.php');
if(isset($_POST["Click"]))
{
            $tn=$_POST['tourname'];
            $np=$_POST['tmname'];
			$pp=$_POST['uname'];
            $score=$_POST['score'];
          
$sql=mysqli_query($conn,"insert into score2(tournamentname,teamname,name,score)values ('$tn','$np','$pp','$score')"); 
$result=mysqli_query($conn,$sql);
//header('location:managescore.php');
echo "<script>alert('Inserted Successfully');window.location.href='../managescore';</script>";

}
?>