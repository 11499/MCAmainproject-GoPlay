<?php
$servername = "localhost"; 
$username = "root";
 $password = "";
 $db= "st_db";
$conn = mysqli_connect($servername, $username, $password, $db)or die ("not connected ");
?>