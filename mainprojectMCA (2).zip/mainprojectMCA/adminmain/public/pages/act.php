<?php
include('connection.php');
if($_POST['id']){
$id=$_POST['id'];
if($id==0){
	echo "<option>Select Team</option>";
}else{
	$sql = mysqli_query($conn,"SELECT * FROM `tb_teams`");
	while($row = mysqli_fetch_array($sql)){
		echo '<option value="'.$row['team_id'].'">'.$row['teamname'].'</option>';
		}
	}
}
?>