
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Register</title>

    <!-- Font Icon -->
    <link rel="stylesheet" href="fonts/material-icon/css/material-design-iconic-font.min.css">

    <!-- Main css -->
    <link rel="stylesheet" href="css/style.css">
</head>
<script type="text/javascript">
  
  var emailreg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
  
     function doSubmit()
	 {
		 var illegalChars = /\W/; // allow letters, numbers, and underscores
         if(document.getElementById('name').value == "")
		{
			alert("Please Enter Your Name");
			document.getElementById("form1").name.focus();
		}
		else if( /[^a-zA-Z ]/.test( document.getElementById('name').value ) ) 
		{
		   alert('Name is not alphanumeric');
		   document.getElementById("form1").name.focus();
		}
		else if(document.getElementById('username').value =="")
		{
			alert("Please Enter Username");
			document.getElementById("form1").username.focus(); 
		}
		else if (illegalChars.test(username.value)) 
		{
			alert("Username can accept alphabets numbers and underscore only");
			document.getElementById('form1').username.focus();
		}
		else if(document.getElementById('username').value.length <=4)
		{
			alert("Username is too short");
			document.getElementById('form1').username.focus();
		}
		else if(document.getElementById('username').value.length >=15)
		{
			alert("Username is long");
			document.getElementById('form1').username.focus();
		}
		else if(document.getElementById('passwd').value =="")
		{
			alert("Please Enter Password");
			document.getElementById("form1").passwd.focus();
		}
		else if(document.getElementById('passwd').value.length <=4)
		{
			alert("Password is too short");
			document.getElementById('form1').passwd.focus();
		}
		else if(document.getElementById('passwd').value.length >=15)
		{
			alert("Password is long");
			document.getElementById('form1').passwd.focus();
		}
		else if(document.getElementById('passwd').value != document.getElementById('conpassword').value)
		{
			alert("Passwords Should Match");
			document.getElementById("form1").conpassword.focus();
		}
				
		else if(document.getElementById('emailid').value == "")
		{
			alert("Please Enter Email ID");
			document.getElementById("form1").emailid.focus();
		}
		else if(emailreg.test(document.getElementById('emailid').value) == false)
		{
			alert("Invalid Email ID");
			document.getElementById("form1").emailid.focus();
		}
		else if(document.getElementById('mobile').value == "")
		{
			alert("Please Enter Mobile");
			document.getElementById("form1").mobile.focus();
		}
		else if(isNaN(document.getElementById('mobile').value))
		{
			alert("Mobile Should Be A Number");
			document.getElementById("form1").mobile.focus();
		}
		else if(document.getElementById('mobile').value.length != 10)
		{
			alert("Invalid Mobile Number");
			document.getElementById("form1").mobile.focus();
		}
		
		else if(document.getElementById('place').value == "")
		{
			alert("Please Enter your place");
			document.getElementById('form1').username.focus();
		}
		else if(document.getElementById('sn').value == "")
		{
			alert("Please Enter sports name");
			document.getElementById('form1').username.focus();
		}
        else if(document.getElementById('tn').value == "")
		{
			alert("Please Enter your team name");
			document.getElementById('form1').username.focus();
		}
		else
		{
			document.getElementById('form1').action = 'insertuser.php';
	        document.getElementById('form1').submit();
		}
	 }

	</script>
<body>

    <div class="main">

        <!-- Sign up form -->
        <section class="signup">
            <div class="container">
                <div class="signup-content">
                    <div class="signup-form">
                        <h2 class="form-title">Registration</h2>
                        <form method="POST" class="register-form" id="form1" name="form1" action="#" >
                            <div class="form-group">
                                <label for="name"><i class="zmdi zmdi-account material-icons-name"></i></label>
                                <input type="text" name="name" id="name" placeholder=" Name"/>
                            </div>
                            <div class="form-group">
                                <label for="name"><i class="zmdi zmdi-account material-icons-name"></i></label>
                                <input type="text" name="username" id="username" placeholder="Your Username"/>
                            </div>
                          
                            <div class="form-group">
                                <label for="pass"><i class="zmdi zmdi-lock"></i></label>
                                <input type="password" name="passwd" id="passwd" placeholder="Password"/>
                            </div>
                            <div class="form-group">
                                <label for="re-pass"><i class="zmdi zmdi-lock-outline"></i></label>
                                <input type="password" name="conpassword" id="conpassword" placeholder="Confirm password"/>
                            </div>
                            <div class="form-group">
                                <label for="email"><i class="zmdi zmdi-email"></i></label>
                                <input type="email" name="emailid" id="emailid" placeholder="Your Email"/>
                            </div>
                            <div class="form-group">
                                <label for="name"><i class="zmdi zmdi-account material-icons-name"></i></label>
                                <input type="text" name="mobile" id="mobile" placeholder="Mobile"/>
                            </div>
                            <div class="form-group">
                                <label for="name"><i class="zmdi zmdi-account material-icons-name"></i></label>
                                <input type="text" name="place" id="place" placeholder="Place"/>
                            </div>
                            
                            <div class="form-group">
                                <label for="name"><i class="zmdi zmdi-account material-icons-name"></i></label>
                                <input type="text" name="sn" id="sn" placeholder="Spotrs Name"/>
                            </div>
                            <div class="form-group">
                                <label for="name"><i class="zmdi zmdi-account material-icons-name"></i></label>
                                <input type="text" name="tn" id="tn" placeholder="Team Name"/>
                            </div>
                            
                            <div class="form-group">
                                <input type="checkbox" name="agree-term" id="agree-term" class="agree-term" />
                                <label for="agree-term" class="label-agree-term"><span><span></span></span>I agree all statements in  <a href="#" class="term-service">Terms of service</a></label>
                            </div>
                            <div class="form-group form-button">
                            <input type="submit" name="signin"  class="form-submit" value="Submit" onclick='doSubmit()'/>
                               </div>
                        </form>
                    </div>
                    <div class="signup-image">
                        <!--<figure><img src="" alt="sing up image"></figure>-->
                        <a href="login.php" class="signup-image-link">I am already member</a>
                    </div>
                </div>
            </div>
        </section>

        <!-- Sing in  Form -->
       

    </div>
   
    <!-- JS 
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="js/main.js"></script>-->
</body><!-- This templates was made by Colorlib (https://colorlib.com) -->
</html>