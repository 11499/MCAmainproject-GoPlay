<?php
$tid = $_GET['id'];
	$r_id=$_GET['uid'];
	include('connection.php');

    $query = "select * from tb_user where log_id='$r_id'";
    $res = mysqli_query($conn, $query);
    $r = mysqli_fetch_array($res);
    $lid=$r["log_id"]; 
    #echo $pid;
	mysqli_query($conn,"update `tb_login` set usertype='user',approve=1 where log_id='$lid'");
    // mysqli_query($conn,"");
    mysqli_query($conn,"UPDATE `tb_teams` SET `user_id`='$lid' WHERE  `team_id`='$tid'");
	header('location:../addcaptain.php');
?>