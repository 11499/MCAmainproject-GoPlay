<?php
	include 'connection.php';
      $name=$_POST['name'];
      $uname=$_POST['username'];
	  $pwd=$_POST['passwd'];
	  $email=$_POST['emailid'];
	  $mob=$_POST['mobile'];
      $plc=$_POST['place'];
      $sn=$_POST['sn'];
	  $tn=$_POST['tn'];
	 	  
	$sel1="select * from `tb_login` where `username`='$uname'";
	$result=mysqli_query($conn,$sel1);
	$num=mysqli_num_rows($result);
	 if($num>0)
	  {
	 ?>
	 <script> 
	  alert("Username already in exist");
	</script>
	  <?php
	  }
	  else
	  {
		  
			
	$sql="INSERT INTO `tb_login`(`username`,`passwd`,`usertype`,`status`) VALUES('$uname','$pwd','user','1')";
	if(mysqli_query($conn,$sql))
	{
		$result1=mysqli_query($conn,"select * from tb_login where username='$uname'");
		$row=mysqli_fetch_assoc($result1);
		//$sql1="INSERT INTO `tb_user`(`log_id`,`name`,`email`,`mobile`,`place`,`sp_type`,`team_name`,`doj`) VALUES('$row[log_id]','$name','$email','$mob','$plc','$sn','$tn',now())";
$sql1="INSERT INTO `tb_user`( `log_id`, `name`, `email`, `mobile`, `place`, `sp_type`, `team_name`) VALUES ('$row[log_id]','$name','$email','$mob','$plc','$sn','$tn')";
       		 if(mysqli_query($conn,$sql1))
		{

			
			if(headers_sent()){
			die('<script type="text/javascript">window.location.href="login.php?e=1"</script>');
			}
			else {
			header("location:login.php?e=1");
			die();
			}
		}

	}
	else {
		?>
		<script>
		alert("error");
		</script>
		<?php
		}
}

mysqli_close($conn);			
?> 
	
   