<?php
include('../connection.php');
if(isset($_POST["Click"]))
{
            $tn=$_POST['tname'];
            $np=$_POST['np'];
            $rule=$_POST['rule'];
		
$sql=mysqli_query($conn,"insert into tb_games(G_name,n_particip,rules)values ('$tn','$np','$rule')"); 
//$sql=mysqli_query($con,"insert into add_category(type,description,theme)values ('$type','$description','$theme')");
$result=mysqli_query($conn,$sql);
echo "<script>alert('Inserted Successfully');window.location.href='../managegames.php';</script>";
 
//header('location:../managegames.php');

}
?>