<?php
session_start();

include("connection.php");



	$conn = mysqli_connect($servername, $username, $password);
	mysqli_select_db($conn, $db);
	$username = $_POST["username"];
	$passwd = $_POST["passwd"];
	$sql2 = "select * from tb_login where username='" . $username . "' AND passwd='" . $passwd . "'";


	$result = mysqli_query($conn, $sql2);

	if ($result) {
		if ($row = mysqli_fetch_array($result)) {
			$_SESSION['id'] = $row['log_id'];
			if ($row[3] == "Admin") {
			?>	
				<script type="text/Javascript">
					window.location.href="../adminmain/public/pages/page1.php"</script>
			<?php
			} else if ($row[3] == "captain"&& $row[4]== "1") {

			?>
				<script type="text/Javascript">
					window.location.href="../adminmain/public/user/page1.php"</script>
				
						<?php
			} 
			else if ($row[3] == "user"&& $row[4]== "1") {

				?>
					<script type="text/Javascript">
						window.location.href="../adminmain/public/player/page1.php"</script>
					
							<?php
				}
             else if ($row[3] == "player"&& $row[4]== "1") {

				?>
					<script type="text/Javascript">
						window.location.href="../adminmain/public/player/page1.php"</script>
					
							<?php
				}				
			else {
				
				echo "Invalid Username and Password";
			}
		}
	}
	


?>
