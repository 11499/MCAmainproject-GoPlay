<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Go-Play</title>
        <!-- Favicon-->
        <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
        <!-- Bootstrap icons-->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet" />
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="css/styles.css" rel="stylesheet" />
        <script type="text/javascript" src="../assets/scripts/main.js"></script>

    </head>
    <body>
        <!-- Navigation-->
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container px-4 px-lg-5">
                <a class="navbar-brand" href="#!"></a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0 ms-lg-4">
                        <li class="nav-item"><a class="nav-link active" aria-current="page" href="../page1.php">Home</a></li>
                                               
                    </ul>
                    <form class="d-flex">
                        <button class="btn btn-outline-dark" type="submit">
                                 </button>
                    </form>
                </div>
            </div>
        </nav>
        <!-- Header-->
        <header class="bg-dark py-5">
            <div class="container px-4 px-lg-5 my-5">
                <div class="text-center text-white">
                    <h1 class="display-4 fw-bolder">Register Tournaments</h1>
                    <p class="lead fw-normal text-white-50 mb-0">Upcoming Tournaments...</p>
                </div>
            </div>
        </header>
        <!-- Section-->
        <section class="py-5">
            <div class="container px-4 px-lg-5 mt-5">
                <div class="row gx-4 gx-lg-5 row-cols-2 row-cols-md-3 row-cols-xl-4 justify-content-center">
                <?php

include('connection.php');
$r_id=$_GET['uid'];
$sel_query="SELECT * FROM tb_tournament where 'status'=0"; 
$result = mysqli_query($conn,$sel_query);
while($row = mysqli_fetch_assoc($result)) { 
 ?>
                <div class="col mb-5">
                        <div class="card h-100">
                            <!-- Product image-->
                           <!-- <img class="card-img-top" src='images/".$row['image']."' alt="..." />-->
                            <img class="card-img-top" src='images/tr2.jfif' alt="..." />
                        
                            <!-- Product details-->
                            <div class="card-body p-4">
                                <div class="text-center">
                                    <!-- Product name-->
                                    <h5 class="fw-bolder"><?php echo $row["t_name"]; ?></h5>
                                    <!-- Product price-->
                                   Reg Fee : <?php echo $row["price"]; ?>
                                </div>
                            </div>
                            <!-- Product actions-->
                            <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                                <div class="text-center"><a href="index2.php?uid=<?php echo $row['trmn_id'];?>" ><button type="button" class="btn mr-2 mb-2 btn-primary" >
                                           View Details
                                        </button></div></a>
                                <div class="text-center"><a class="btn btn-outline-dark mt-auto" href="../payment/paymentgateway.php?uid=<?php echo $row['trmn_id'];?>&&tid=<?php echo $r_id;?>">Register Now</a>
  </div>
                               
                     
                    
                            </div>
                        </div>
                    </div>
                    <?php  } ?>       
                </div>
            </div>
        </section>
        <!-- Footer-->
       
        <!-- Bootstrap core JS-->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Core theme JS-->
        <script src="js/scripts.js"></script>
    </body>
</html>
<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Tournament Details</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <?php
include('connection.php');
$sel_query="SELECT * FROM tb_tournament"; 
$result = mysqli_query($conn,$sel_query);
$row = mysqli_fetch_assoc($result) ?>
            <div class="modal-body">
                <p class="mb-0">place :<?php echo $row["place"]; ?></p>
                <p class="mb-0">stadium:<?php echo $row["stadium"]; ?></p>
                <p class="mb-0">Time :<?php echo $row["time"]; ?></p>
                <p class="mb-0">start date :<?php echo $row["start_date"]; ?></p>
                <p class="mb-0">end_date<?php echo $row["end_date"]; ?></p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
              
            </div>
        </div>
    </div>
</div>