<?php 
session_start();

include('connection.php');
include('pdf_mc_table.php');
if(isset($_POST['genaratepdf']))
{
  $result = mysqli_query($conn,"select tb_bookingpay.*,tb_login.*,tb_booking.* from tb_bookingpay join tb_login on tb_login.log_id=tb_bookingpay.log_id JOIN tb_booking on tb_booking.book_id=tb_bookingpay.book_id and tb_login.log_id;") or die(mysqli_error($conn));
  $pdf = new PDF_MC_TABLE();
  $pdf->AddPage();

  $pdf->SetFont('Arial', 'B', 15);
  $pdf->Cell(176, 5, 'Team Details', 0, 0, 'C');
  $pdf->Ln();
  $pdf->Ln();
  $pdf->Ln();

  $pdf->SetFont('Arial','',10);
  
  $pdf->SetWidths(Array(11,30,30,30,30,30,30,30));

  $pdf->SetLineHeight(5);

  $pdf->SetFont('Arial','B',10);
  $pdf->Cell(11,5,"Sl No",1,0);
  $pdf->Cell(30,5,"Amount",1,0);
  $pdf->Cell(30,5,"Date",1,0);
 
  
 
  $pdf->Ln();
  
  $pdf->SetFont('Arial','',10);	
  $i=1;
  foreach($result as $row) {
    $pdf->Row(Array(
        $i,
		$row['tamount'],
        $row['date_added'],
       
	));
	$i++;
  }
  $pdf->Output();
}
?>
