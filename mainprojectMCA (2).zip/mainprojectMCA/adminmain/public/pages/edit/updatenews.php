<?php
include('connection.php');
             $tn=$_POST['title'];
            $np=$_POST['description'];
			$ns=$_GET['uid'];
          
$sql=mysqli_query($conn,"UPDATE `tb_news` SET `titile`='$tn',`description`='$np' WHERE'n_id'='$ns'"); 
echo $sql;
$result=mysqli_query($conn,$sql);
//header('location:../addnews.php');

?>