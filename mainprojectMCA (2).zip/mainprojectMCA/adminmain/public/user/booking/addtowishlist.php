<?php
   
	include('connection.php');
    $tid = $_GET['u'];
	$r_id=$_GET['uid'];
    		
$sql=mysqli_query($conn,"insert into tb_wishlist(trmn_id,user_id)values ('$r_id','$tid')"); 
$result=mysqli_query($conn,$sql);
header('location:wishlist.php');

?>