<?php
	$r_id=$_GET['uid'];
	include('connection.php');

    $query = "select * from tb_booking where book_id='$r_id'";
    $res = mysqli_query($conn, $query);
    $r = mysqli_fetch_array($res);
    $lid=$r["book_id"]; 
    #echo $pid;

	
	mysqli_query($conn,"update `tb_booking` set canselreq='Approved' where book_id='$r_id'");
	header('location:../booking.php');
?>