<?php
include('../connection.php');
if(isset($_POST["Click"]))
{
            $name=$_POST['s_name'];
            $tn=$_POST['teamname'];
            $fin=$_POST['final'];
            $wi=$_POST['winner'];
            $sctype=$_POST['scoretype'];
            $score=$_POST['score'];
           
$sql=mysqli_query($conn,"insert into tb_result(tournamentname,participant,finalist,winner,scoretype,score) values ('$name','$tn','$fin','$wi','$sctype','$score')"); 
$result=mysqli_query($conn,$sql);
//header('location:../result.php');
echo "<script>alert('Inserted Successfully');window.location.href='../manageresult';</script>";

}

?>